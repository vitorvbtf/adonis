// import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Disciplina from "App/Models/Disciplina";

export default class   DisciplinasController {
    index() {
        return Disciplina.all()
}
    store(){
    const dados = {nome: 'ADS', curso_id:1 }
    return Disciplina.create(dados)

  }

}
